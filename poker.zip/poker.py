from random import *
from enum import Enum
from enum import IntEnum
from os import sys
import tkinter as tk
from tkinter import *

print('Welcome to poker!')

#writes all the rules in a file, reads it, and prints it out
my_file = open('rules.txt','w')
my_file.write('1. A double is 2 of the same number' + '\n')
my_file.write('2. A triple is 3 of the same number'+ '\n')
my_file.write('3. A full house is a triple and a double'+ '\n')
my_file.write('4. A straight is 5 consecutive numbers'+ '\n')
my_file.write('5. A flush is 5 consecutive suits'+ '\n')
my_file.write('6. A royal flush is 5 consecutive numbers with the same suits'+ '\n')
my_file.write('7. A bomb is 4 of the same number'+ '\n')
my_file.write('You start off with 100 dollars and minimum bet is 5 dollars'+ '\n')
my_file.write('A double or triple will add 5 to your pot and anything above that will double it. If you do not have anything, you lose the pot.')
my_file.close()
my_file = open('rules.txt','r')
line = my_file.read()
print(line)

#will set up the program if user decides to play; will exit if otherwise
play = input('Start? Yes or No ')
if play == 'Yes':
    print('\n')
    #deck of cards as a list for the deck to be appended to it
    deck_of_cards = []
    
    money = 95
    #defines all the cards in a deck of cards
    class Card(IntEnum):
        two = 2
        three = 3
        four = 4
        five = 5
        six = 6
        seven = 7
        eight = 8
        nine = 9
        ten = 10
        jack = 11
        queen = 12
        king = 13
        ace = 14
    
    class Suit(Enum):
        spades = 'spades'
        clubs = 'clubs'
        hearts = 'hearts'
        diamonds = 'diamonds'
        
    class PlayingCard:
        def __init__(self, card_value, card_suit):
            self.card = card_value
            self.suit = card_suit
        def get_info(user='',password=''):
            if user == 'Ethan' and password == 'Wong':
                print(' ')
            name = []
            x = get_info('Ethan','Wong')
            name.append(x)
            name.sort()
        
    #creates the deck by appending the suit and the card to the list
    def create():
        for suit in Suit:
            for card in Card:
                deck_of_cards.append(PlayingCard(Card(card), Suit(suit)))
        return deck_of_cards
       
    def drawcard(deck):
        random = randint(0, len(deck) -1)
        return deck.pop(random)
    
    create()
    deck1 = list(deck_of_cards)
    
    #draws 2 cards for the cards in your hand
    for i in range(1,3):
        test_card = drawcard(deck1)
        print('you drew a', test_card.card, test_card.suit)
    print('\n')
    #draws 3 cards for the cards on the table
    for i in range(1,4):
        test_card = drawcard(deck1)
        print('the cards on the table are' , test_card.card, test_card.suit)
    print('\n')
elif play == 'No':
    print('Goodbye')
    sys.exit(0)
    
#the actual game; the 3 reveals of cards
def game(event):
    global money
    move = input('Do you want to check, raise, or fold? ')
    if move == 'check':
        pot = 5
        print('Your bet is still at 5')
        print('\n')
        bet1 = 0
    elif move == 'raise':
        bet1 = input('How much do you want to raise? ')
        new_money = money - int(bet1)
        pot = int(bet1) + 5
        money = new_money
        print('You now have',int(new_money),'dollars and the pot is at',pot)
        print('\n')
    elif move == 'check' and move != 'raise':
        pot = 5
    elif move == 'fold':
        print('Lose!')
        sys.exit(0)

    #draws a card to reveal the fourth card
    test_card = drawcard(deck1)
    print('the fourth card is' , test_card.card, test_card.suit)

    move = input('Do you want to check, raise, or fold? ')
    if move == 'check':
        print('Your bet is still at',pot)
        bet2 = 0
        print('\n')
    elif move == 'raise':
        bet2 = input('How much do you want to raise? ')
        new_money = money - int(bet2)
        pot = int(bet1) + int(bet2) + 5
        money = new_money
        print('You now have',int(new_money),'dollars and the pot is at',pot)
        print('\n')
    elif move == 'fold':
        print('Lose!')
        sys.exit(0)

    #draws a card to reveal the fifth card
    test_card = drawcard(deck1)
    print('the final card is' , test_card.card, test_card.suit)

    move = input('Do you want to check, raise, or fold? ')
    if move == 'check':
        print('Your bet is still at',pot)
        print('\n')
    elif move == 'raise':
        bet3 = input('How much do you want to raise? ')
        new_money = money - int(bet3)
        pot = int(bet1) + int(bet2) + int(bet3) + 5
        money = new_money
        print('You now have',int(new_money),'dollars and the pot is at',pot)
        print('\n')
    elif move == 'fold':
        print('Lose!')
        sys.exit(0)

    print('Check the rules to see what you have!')
    print('Thanks for playing!')

#GUI consists of a picture that is fitted on a 300 by 400 frame
#with a button that calls the game function which plays the game
class GUI:
    root = Tk()
    root.title('Poker')
    canvas = Canvas(root, width = 300, height = 400)
    canvas.pack()
    myimage = PhotoImage(file = 'C:\\Users\\kwong\\Documents\\ace.png')
    canvas.create_image(0, 0, anchor = NW, image = myimage)
    button1 = Button(root, text = 'Play!')
    button1.bind('<Button-1>',game)
    button1.pack()
    root.mainloop()

my_gui = GUI





    
    
